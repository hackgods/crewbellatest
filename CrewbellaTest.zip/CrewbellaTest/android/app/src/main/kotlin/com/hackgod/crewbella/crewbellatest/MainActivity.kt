package com.hackgod.crewbella.crewbellatest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
